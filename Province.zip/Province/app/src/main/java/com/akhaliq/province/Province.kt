package com.akhaliq.province

data class Province (
    var imageProvince : String = "",
    var namaPropinsi : String= "",
    var keterangan : String= "",
    var luas : String= "",
    var laguDaerah : String= "",
    var jumlahSatuanPemerintahan : String= "",
    var ibuKota : String ="",
    var hariJadi : String=""
)